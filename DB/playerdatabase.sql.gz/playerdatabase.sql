-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2019 at 07:28 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `playerdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `Serial_No` int(11) NOT NULL,
  `UserName` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`Serial_No`, `UserName`, `Password`, `Email`) VALUES
(1, 'Anik Islam', '123', 'islam.anik1680@gmail.com'),
(2, 'Anik ahmen', '123', 'sakil@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `battingrecord`
--

CREATE TABLE `battingrecord` (
  `Serial_No` int(11) NOT NULL,
  `PlayerID` varchar(250) NOT NULL,
  `NumberOfMatch` varchar(250) NOT NULL,
  `NumberOfInnings` varchar(250) NOT NULL,
  `TotalRun` varchar(250) NOT NULL,
  `HighScore` varchar(250) NOT NULL,
  `Average` varchar(250) NOT NULL,
  `Rate` varchar(250) NOT NULL,
  `Century` varchar(250) NOT NULL,
  `fifthy` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `battingrecord`
--

INSERT INTO `battingrecord` (`Serial_No`, `PlayerID`, `NumberOfMatch`, `NumberOfInnings`, `TotalRun`, `HighScore`, `Average`, `Rate`, `Century`, `fifthy`) VALUES
(1, '', '1', '1', '55', '55', '55', '120.33', '0', '1'),
(2, '', '1', '1', '55', '55', '55', '120.33', '0', '1'),
(3, 'Ani001', '3', '3', '188', '111', '37', '63', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `bowlingrecord`
--

CREATE TABLE `bowlingrecord` (
  `Serial_No` int(11) NOT NULL,
  `PlayerID` varchar(250) NOT NULL,
  `TotalWicket` varchar(250) NOT NULL,
  `TotalFiveWicket` varchar(250) NOT NULL,
  `Economy` varchar(250) NOT NULL,
  `Stamping` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bowlingrecord`
--

INSERT INTO `bowlingrecord` (`Serial_No`, `PlayerID`, `TotalWicket`, `TotalFiveWicket`, `Economy`, `Stamping`) VALUES
(1, '', '1', '0', '5.5', '0'),
(2, '', '1', '0', '5.5', '0'),
(3, 'Ani001', '15', '1', '3.6666666666667', '13');

-- --------------------------------------------------------

--
-- Table structure for table `playerimage`
--

CREATE TABLE `playerimage` (
  `Serial_No` int(11) NOT NULL,
  `PlayerID` varchar(250) NOT NULL,
  `Image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `playerimage`
--

INSERT INTO `playerimage` (`Serial_No`, `PlayerID`, `Image`) VALUES
(1, 'Ani001', 'radek-grzybowski-eBRTYyjwpRY-unsplash.jpg'),
(2, 'virat123', 'IMG_20190723_102348.jpg'),
(3, 'anik123', 'IMG_20190723_102329.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `Serial_No` int(11) NOT NULL,
  `Oppnent1` varchar(250) NOT NULL,
  `Oppnent2` varchar(250) NOT NULL,
  `Type` varchar(250) NOT NULL,
  `Venue` varchar(250) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `TypeCondition` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`Serial_No`, `Oppnent1`, `Oppnent2`, `Type`, `Venue`, `Date`, `Time`, `TypeCondition`) VALUES
(3, 'BanglaDesh', 'India', 'T20', 'Mumbai', '2019-08-06', '11:11:00', 'Day-Night'),
(4, 'BanglaDesh', 'India', 'T20', 'Dhaka', '2019-08-06', '11:11:00', 'Day-Night');

-- --------------------------------------------------------

--
-- Table structure for table `team_bangladesh`
--

CREATE TABLE `team_bangladesh` (
  `Serial_No` int(11) NOT NULL,
  `PlayerID` varchar(250) NOT NULL,
  `JerseyNumber` varchar(250) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Age` varchar(250) NOT NULL,
  `birthday` varchar(250) NOT NULL,
  `birthplace` varchar(250) NOT NULL,
  `Country` varchar(250) NOT NULL,
  `PlayerType` varchar(250) NOT NULL,
  `BattingStyle` varchar(250) NOT NULL,
  `BowlingStyle` varchar(250) NOT NULL,
  `Availability` varchar(250) NOT NULL,
  `rating` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_bangladesh`
--

INSERT INTO `team_bangladesh` (`Serial_No`, `PlayerID`, `JerseyNumber`, `Name`, `Age`, `birthday`, `birthplace`, `Country`, `PlayerType`, `BattingStyle`, `BowlingStyle`, `Availability`, `rating`) VALUES
(1, '0', '', 'Anik Islam', '22', '6-3-1997', 'Dhaka', 'team_bangladesh', 'Allrounder', 'Right Handed Batsmen', 'Right Handed Bowler', '0', '0'),
(2, '10', '', 'Anik Islam', '22', '6-3-1997', 'Dhaka', 'team_bangladesh', 'Allrounder', 'Right Handed Batsmen', 'Right Handed Bowler', '0', '0'),
(3, 'Ani001', '11', 'Anik Islam', '22', '6-3-1997', 'Dhaka', 'team_bangladesh', 'Allrounder', 'Right Handed Batsmen', 'Right Handed Bowler', '0', '111'),
(4, 'anik123', '50', 'ANik islam', '12', '8-9-1997', 'dhaka', 'team_bangladesh', 'Allrounder', 'Right Handed Batsmen', 'Right Handed Bowler', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `team_india`
--

CREATE TABLE `team_india` (
  `Serial_No` int(11) NOT NULL,
  `PlayerID` varchar(250) NOT NULL,
  `JerseyNumber` varchar(250) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Age` varchar(250) NOT NULL,
  `birthday` varchar(250) NOT NULL,
  `birthplace` varchar(250) NOT NULL,
  `Country` varchar(250) NOT NULL,
  `PlayerType` varchar(250) NOT NULL,
  `BattingStyle` varchar(250) NOT NULL,
  `BowlingStyle` varchar(250) NOT NULL,
  `Availability` varchar(250) NOT NULL,
  `rating` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_india`
--

INSERT INTO `team_india` (`Serial_No`, `PlayerID`, `JerseyNumber`, `Name`, `Age`, `birthday`, `birthplace`, `Country`, `PlayerType`, `BattingStyle`, `BowlingStyle`, `Availability`, `rating`) VALUES
(1, 'virat123', '18', 'Virat kohli', '32', '11-3-1986', 'Mumbai', 'team_india', 'Allrounder', 'Right Handed Batsmen', 'Right Handed Bowler', '0', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `battingrecord`
--
ALTER TABLE `battingrecord`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `bowlingrecord`
--
ALTER TABLE `bowlingrecord`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `playerimage`
--
ALTER TABLE `playerimage`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `team_bangladesh`
--
ALTER TABLE `team_bangladesh`
  ADD PRIMARY KEY (`Serial_No`);

--
-- Indexes for table `team_india`
--
ALTER TABLE `team_india`
  ADD PRIMARY KEY (`Serial_No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `battingrecord`
--
ALTER TABLE `battingrecord`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bowlingrecord`
--
ALTER TABLE `bowlingrecord`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `playerimage`
--
ALTER TABLE `playerimage`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `team_bangladesh`
--
ALTER TABLE `team_bangladesh`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `team_india`
--
ALTER TABLE `team_india`
  MODIFY `Serial_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
